
/*
Her er vår database classe, enkel database med 3 verdier, id int, varer som strong, og listenavn som string
*/

class DatabaseClass(val id: Int, val varer: String, val listenavn: String )