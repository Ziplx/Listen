import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import com.example.minliste.MainActivity
/*
main classen for håndtering av databasen vedrørende
slettning, oppdatering og fremvisning av data.
 */

class Databasehåndtør(context: MainActivity) :
    SQLiteOpenHelper(context, DATABASE_NAVN, null, DATABASE_VERSION) {

    companion object {
        private val DATABASE_VERSION = 1
        private val DATABASE_NAVN = "Handlelistedatabase"

        private val TABLE_VARER = "Varetabell"

        private val KEY_ID = "_id"
        private val KEY_NAVN = "tittel"
        private val KEY_Antall = "varer"
    }
/*
OnCreate lager databasen brukt i databaseclass
 */
    override fun onCreate(db: SQLiteDatabase?) {

        val CREATE_CONTACTS_TABLE = ("CREATE TABLE " + TABLE_VARER + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAVN + " TEXT,"
                + KEY_Antall + " TEXT" + ")")
        db?.execSQL(CREATE_CONTACTS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_VARER")
        onCreate(db)
    }
/*
funksjon for å legge til liste innholdet i databasen, legger verdiene
som blir skrevet inn i txt feltene inn i radene i databasen
 */
    fun LeggtilHandleliste(emp: DatabaseClass): Long {
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(KEY_NAVN, emp.varer)
        contentValues.put(KEY_Antall, emp.listenavn)
        val success = db.insert(TABLE_VARER, null, contentValues)

        db.close()
        return success
    }

/*
funsjon for fremvisning av liste der den henter verdier
i databasen og plasserer dem i riktig liste for fremvisning
 */

    fun seListe(): ArrayList<DatabaseClass> {

        val dblist: ArrayList<DatabaseClass> = ArrayList<DatabaseClass>()
        val selectQuery = "SELECT  * FROM $TABLE_VARER"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)

        } catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }

        var id: Int
        var tittel: String
        var innhold: String

        if (cursor.moveToFirst()) {
            do {
                id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                tittel = cursor.getString(cursor.getColumnIndex(KEY_NAVN))
                innhold = cursor.getString(cursor.getColumnIndex(KEY_Antall))

                val database = DatabaseClass(id = id, varer = tittel, listenavn = innhold)
                dblist.add(database)

            } while (cursor.moveToNext())
        }
        return dblist
    }

/*
funksjon for oppdatere listene.
Henter de nye verdiene som blir skrevet inn
i oppdateringsdialogvinduet og overrider dem i databasen
 */

    fun OppdaterListe(emp: DatabaseClass): Int {
        val db = this.writableDatabase
        val Innholdsverdier = ContentValues()
        Innholdsverdier.put(KEY_NAVN, emp.varer)
        Innholdsverdier.put(KEY_Antall, emp.listenavn)

        val success = db.update(TABLE_VARER, Innholdsverdier, KEY_ID + "=" + emp.id, null)

        db.close()
        return success
    }
/*
funksjon for å slette liste.
henter id ved bruk av hvilken liste som er klikket og
sletter alt av innhold i databasen til denne listen
 */
    fun Slettliste(emp: DatabaseClass): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, emp.id)
        val success = db.delete(TABLE_VARER, KEY_ID + "=" + emp.id, null)

        db.close()
        return success
    }
}