package com.example.minliste

import DatabaseClass
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.oppdater.view.*
import kotlinx.android.synthetic.main.vare_liste.view.*
/*
adapter for database innholdet til fremvisning i listview
 */
class ItemAdapter(val context: Context, val items: ArrayList<DatabaseClass>) :
    RecyclerView.Adapter<ItemAdapter.ViewHolder>() {
/*
viser listen
 */

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.vare_liste,
                parent,
                false
            )
        )
    }
/*
On clicklisteners og lignende for varelisten
 */

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = items.get(position)

        holder.tvInnhold.text = item.listenavn

        if (position % 2 == 0) {
            holder.llMain.setBackgroundColor(
                ContextCompat.getColor(
                    context,
                    R.color.colorLightGray
                )
            )
        } else {
            holder.llMain.setBackgroundColor(ContextCompat.getColor(context, R.color.colorWhite))
        }

        holder.tvInnhold.setOnClickListener{
            if (context is MainActivity) {
                context.Apneliste(item)
            }
        }


        holder.lwEndre.setOnClickListener {

            if (context is MainActivity) {
                context.Oppdateringsdialog(item)
            }
        }

        holder.lwSlett.setOnClickListener {

            if (context is MainActivity) {
                context.SlettlisteDialog(item)
            }
        }
    }


    override fun getItemCount(): Int {
        return items.size
    }


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val llMain = view.llMain
        val tvInnhold = view.Innholdvare
        val lwEndre = view.kpEndre
        val lwSlett = view.kpSlett
    }


}