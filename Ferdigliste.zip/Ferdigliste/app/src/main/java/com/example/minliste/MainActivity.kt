package com.example.minliste

import Databasehåndtør
import DatabaseClass
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.oppdater.*
import kotlinx.android.synthetic.main.vare_liste.*
import kotlinx.android.synthetic.main.visliste.*

/*
Hovedsiden for fremvisning av handlelistene og håndtering
 */
class MainActivity : AppCompatActivity() {

/*
start funksjon for å kunne legg lister til i listen og vise dem fram
 */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        kpLeggtil.setOnClickListener {

            Leggtil()
        }



        Viewoppsett()

    }
/*
funksjon for å vise frem listene om det er lister og
vist det ikke er noen lister i databasen vises det ingen lister txt
 */

    private fun Viewoppsett() {

        if (HentVareListe().size > 0) {

            Innholdsliste.visibility = View.VISIBLE
            IngenLister.visibility = View.GONE
            Innholdsliste.layoutManager = LinearLayoutManager(this)
            val itemAdapter = ItemAdapter(this, HentVareListe())
        Innholdsliste.adapter = itemAdapter

        }

         else {

            Innholdsliste.visibility = View.GONE
            IngenLister.visibility = View.VISIBLE
        }
    }
/*
funksjon for å hente database listen
 */
    private fun HentVareListe(): ArrayList<DatabaseClass> {
        val databaseHandler: Databasehåndtør = Databasehåndtør(this)
        val Dbliste: ArrayList<DatabaseClass> = databaseHandler.seListe()

        return Dbliste
    }
/*
funksjon for å legge til verdier i string og gi dem videre til databasen for lagring
 */
    private fun Leggtil() {
        val tittel = enTittel.text.toString()
        val varer = Enlisteid.text.toString()
        val databaseHandler: Databasehåndtør = Databasehåndtør(this)
        if (!tittel.isEmpty() && !varer.isEmpty()) {
            val status =
                    databaseHandler.LeggtilHandleliste(DatabaseClass(0, tittel, varer))
            if (status > -1) {
                Toast.makeText(applicationContext, "Innhold Lagret", Toast.LENGTH_LONG).show()
                enTittel.text.clear()
                Enlisteid.text.clear()

                Viewoppsett()
            }
        } else {
            Toast.makeText(
                    applicationContext,
                    "Noen felter er tomme",
                    Toast.LENGTH_LONG
            ).show()
        }
    }

/*
funksjon for oppdaterings activity ved bruk av dialogboks for fremvisning og endring
av innholdet i listen
 */
    fun Oppdateringsdialog(databaseClass: DatabaseClass) {
        val OppdaterDialog = Dialog(this, R.style.Theme_Dialog)
        OppdaterDialog.setCancelable(false)
        OppdaterDialog.setContentView(R.layout.oppdater)
        OppdaterDialog.OppdatertTittel.setText(databaseClass.varer)
        OppdaterDialog.OppdaterListeinnhold.setText(databaseClass.listenavn)
        OppdaterDialog.kpOppdater.setOnClickListener(View.OnClickListener {

            val tittel = OppdaterDialog.OppdatertTittel.text.toString()
            val innhold = OppdaterDialog.OppdaterListeinnhold.text.toString()

            val databaseHandler: Databasehåndtør = Databasehåndtør(this)

            if (!tittel.isEmpty() && !innhold.isEmpty()) {
                val status =
                        databaseHandler.OppdaterListe(DatabaseClass(databaseClass.id, tittel, innhold))
                if (status > -1) {
                    Toast.makeText(applicationContext, "Innhold Oppdatert.", Toast.LENGTH_LONG).show()

                    Viewoppsett()

                    OppdaterDialog.dismiss()
                }
            } else {
                Toast.makeText(
                        applicationContext,
                        "Et felt er blankt",
                        Toast.LENGTH_LONG
                ).show()
            }
        })
        OppdaterDialog.kpAvbryt.setOnClickListener(View.OnClickListener {
            OppdaterDialog.dismiss()
        })

        OppdaterDialog.show()
    }

/*
funksjon for sletting av liste ved bruk av dialogvindu
 */
    fun Apneliste(databaseClass: DatabaseClass) {
    val VislisteDialog = Dialog(this, R.style.Theme_Dialog)
   VislisteDialog.setCancelable(false)
   VislisteDialog.setContentView(R.layout.visliste)
   VislisteDialog.innhold.setText(databaseClass.varer)
   VislisteDialog.Tittel.setText(databaseClass.listenavn)

    VislisteDialog.kplukk.setOnClickListener(View.OnClickListener {
        VislisteDialog.dismiss()
    })
    VislisteDialog.show()
}





    fun SlettlisteDialog(databaseClass: DatabaseClass) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Slett liste")
        builder.setMessage("Er du sikker du vil slette ${databaseClass.listenavn}?")
        builder.setIcon(android.R.drawable.ic_dialog_alert)


        builder.setPositiveButton("Ja") { dialogInterface, which ->


            val databaseHandler: Databasehåndtør = Databasehåndtør(this)
            val status = databaseHandler.Slettliste(DatabaseClass(databaseClass.id, "", ""))
            if (status > -1) {
                Toast.makeText(
                        applicationContext,
                        "Liste slettet.",
                        Toast.LENGTH_LONG
                ).show()

                Viewoppsett()
            }

            dialogInterface.dismiss()
        }

        builder.setNegativeButton("Nei") { dialogInterface, which ->
            dialogInterface.dismiss()
        }

        val alertDialog: AlertDialog = builder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}